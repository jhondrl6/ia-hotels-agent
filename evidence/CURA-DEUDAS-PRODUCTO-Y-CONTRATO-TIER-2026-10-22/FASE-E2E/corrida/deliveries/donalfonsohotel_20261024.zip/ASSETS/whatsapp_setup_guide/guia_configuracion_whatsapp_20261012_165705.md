# Configuración de WhatsApp — Donalfonsohotel

**Estado del canal: NO VERIFICADO. Esta guía no instala nada.**

Servicio: preparación y validación del canal de WhatsApp de Donalfonsohotel.
Sitio inspeccionado: `https://www.donalfonsohotel.com/`

## Por qué recibes esta guía y no un botón

Un botón de WhatsApp solo funciona si apunta a un número concreto y confirmado. En la
auditoría no pudimos confirmar un número utilizable para Donalfonsohotel, y un botón sin
número verificable se publica roto: el huésped que lo pulsa no llega a ninguna parte.

Por eso esta entrega es una solicitud de validación, no una instalación. Cuando
confirmes el número, el botón se genera e instala como paso siguiente.

Qué **no** afirma este documento: no afirma que Donalfonsohotel no tenga WhatsApp. Afirmar
eso exigiría haber verificado todas las rutas y todos los mecanismos del sitio, y eso
no ocurrió. Lo que afirma es que el número no quedó verificado en lo inspeccionado, y
por tanto no puede publicarse como canal operativo.

## Qué necesitamos de tu parte

Un solo dato, con tu confirmación explícita:

- **Número de WhatsApp que debe quedar público**, en formato internacional
  (indicativo del país + número), con el campo: <Numero WhatsApp a confirmar por el hotel>
- **Quién responde** a ese número (recepción, reservas, o un tercero) y en qué
  horario, porque el botón promete una respuesta.
- **Si el número ya está en Google Business Profile**, dínoslo igual: comparamos
  ambas fuentes y, si difieren, te lo mostramos antes de publicar nada.

Con ese dato confirmado, la entrega del botón pasa a la fase siguiente y este
documento queda cerrado como resuelto.

## Pasos para dejar el canal listo

1. **Confirmar el número** que se va a publicar (el campo de arriba). Sin esta
   confirmación no se genera el botón.
2. **Elegir el mecanismo de publicación**, según cómo opere Donalfonsohotel hoy:
   - *Enlace directo*: un enlace simple en la cabecera o el pie de la web. Es lo que
     instalamos por defecto.
   - *Widget flotante*: un componente de terceros. Si ya tienes uno, dinos cuál: lo
     auditamos en lugar de duplicarlo.
3. **Definir el mensaje pre-rellenado** que abre el chat (por ejemplo una saludo con
   la intención de reserva), para que la conversación entre clasificable.
4. **Decidir la métrica**: si quieres medir cuántos llegan por este canal, se configura
   el evento de clic junto con la analítica del paquete.
5. **Validación humana obligatoria antes de publicar**: una persona del equipo revisa
   que el enlace abre el chat del número correcto. Hasta esa validación, el canal se
   reporta como preparación pendiente, no como instalación realizada.

## Qué se entrega y qué queda pendiente

| Elemento | Estado en esta entrega |
|---|---|
| Guía de preparación y solicitud del número | Entregada |
| Número de WhatsApp publicado | Pendiente de tu confirmación |
| Botón / enlace operativo | No generado a propósito |
| Verificación en el sitio publicado | Pendiente, tras la confirmación |
