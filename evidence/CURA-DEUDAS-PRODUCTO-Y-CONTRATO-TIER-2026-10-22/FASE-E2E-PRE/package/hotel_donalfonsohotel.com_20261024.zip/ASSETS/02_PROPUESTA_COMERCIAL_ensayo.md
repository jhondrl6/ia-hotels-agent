---
generated_at: ${generated_at}
version: ${version}
hotel_id: ${hotel_id}
document_type: PROPUESTA_V6
generator: IA_Hoteles_v4
valid_until: ${valid_until}
---

# PROPUESTA COMERCIAL
## ${hotel_name} - ${hotel_location}

**Fecha**: ${generated_at}  
**Válido por 15 días** — 2 cupos disponibles para julio 2026

---

## 😟 EL PROBLEMA: ¿Cuánto le cuesta depender de Booking y Expedia?

Cada mes, viajeros buscan hoteles en ${hotel_region} a través de Booking.com, Expedia y Google. Cuando reservan por ahí, el hotel paga comisiones del 15-25% por cada reserva.

**Esto es lo que está pasando:**

| El problema | El impacto |
|-------------|------------|
| El viajero busca en Booking/Expedia | Cada reserva cobra comisión |
| Su hotel compite por el mismo cliente | Más caro para el hotel, menos ganancia |
| El cliente no encuentra datos claros en Google Maps | Pierde la reserva antes de llegar |

**Fuga mensual neta estimada (después de acciones recomendadas):** ${monthly_loss} COP/mes
>
> *Nota: Este valor es la fuga neta después de aplicar shift de canal directo (10%) y boost de IA (5%). La comisión OTA bruta sin estas acciones es mayor. Consulte el diagnóstico financiero para el detalle completo.*

#### Referencia regional

| Métrica | Valor |
|---------|-------|
| ADR regional promedio | ${adr_display} |

---

## 😌 LA SOLUCIÓN: Nosotros hacemos todo. Usted solo atiende huéspedes.

Le proponemos un plan integral donde **nosotros implementamos todo** — usted no necesita saber de tecnología, SEO ni Google.

### Paquete: Kit Hospitalidad Digital

**Inversión: ${monthly_investment}/mes** (contrato mes a mes)

**Esto es lo que hacemos por usted:**

${dynamic_services_table}

**No necesita hacer nada técnico. Nosotros implementamos todo.**

${competitors_section}

---

### 📋 Estado de los Entregables

Cada entregable incluye un nivel de preparación:

${asset_quality_table}

${monthly_report_disclaimer}

**Nota sobre Optimización para Asistentes de Voz**: Esta tecnología (Siri, Alexa, Google Assistant) se construye sobre Schema FAQ + Open Graph — ambos incluidos en su kit. No requiere assets adicionales.

---

### 🔧 Assets Técnicos Adicionales

Estos assets técnicos complementan su kit de hospitalidad digital:

${technical_assets_table}

---

## 📸 Fotos: Lo único que necesitamos de usted

Para que su negocio brille en Google Maps, necesitamos fotos de calidad. Esto es lo que debe proveer:

**Tipos de fotos requeridas:**
- 1 fachada (entrada principal)
- 3-5 habitaciones
- 1-2 áreas comunes (recepción, restaurante, sala)
- 1 baño
- 2-3 entorno (jardín, piscina, vista)

**Especificaciones técnicas:**
- Formato: JPG o PNG
- Resolución: Mínimo 1280x720 (mejor si es 1920x1080)
- Orientación: Horizontal (nunca vertical)
- Iluminación: Natural o luz suave (sin flash duro)

**¿Ya tiene fotos?** Envíenoslas y nosotros las optimizamos y subimos.

**Actualización:** Le recordamos que actualizar fotos cada 3-4 meses (temporada alta, mejoras, eventos) mantiene su perfil activo y Google lo premia con mejor posicionamiento. Ofrecemos servicio de actualización trimestral por $150.000 COP.

---



## 💰 PROYECCIÓN: Cuánto recupera vs. cuánto invierte

| Mes | Invierte | Recuperación Estimada | Beneficio |
|-----|----------|----------------------|-----------|
| 1 | ${inv_m1} | ${rec_m1} | ${net_m1} |
| 2 | ${inv_m2} | ${rec_m2} | ${net_m2} |
| 3 | ${inv_m3} | ${rec_m3} | ${net_m3} |
| 4 | ${inv_m4} | ${rec_m4} | ${net_m4} |
| 5 | ${inv_m5} | ${rec_m5} | ${net_m5} |
| 6 | ${inv_m6} | ${rec_m6} | ${net_m6} |

${pain_ratio_note}

> 📊 **Trazabilidad financiera**: La fuga total estimada es de $21.067.200 COP en 6 meses.
> Con nuestro servicio, la recuperación proyectada es de $4.731.342 COP.
> **Origen**: ${trazabilidad_origen}.



---

## 📈 Curva de Maduración: 4 Pilares (GEO → SEO → AEO → IAO)

La recuperación no es instantánea — cada pilar madura a su propio ritmo. Esta es la proyección realista mes a mes:

${curva_4_pilares_tabla}

**Total recuperación proyectada (6 meses): $4.731.342 COP COP**

> **¿Por qué no es lineal?** GEO (Google Business Profile) da resultados desde el día 1. SEO tarda 2-3 meses en indexar y posicionar. AEO/IAO (ChatGPT, Perplexity) requiere 4-6 meses de maduración. Esta curva refleja la realidad operativa de cada pilar.

---

## 🏗️ CAPEX vs OPEX: Lo que es suyo vs. lo que es servicio

| Concepto | Tipo | Monto | ¿De quién es? |
|----------|------|-------|---------------|
| Setup fee (único) | **CAPEX** | $2.500.000 COP | **100% suyo** — Real Estate Digital |
| Fee mensual (×6) | **OPEX** | $2.400.000 COP | Servicio de implementación |

${nota_capex_opex}

### Desglose del Setup Fee (CAPEX)

${capex_breakdown_table}

**Activos digitales que quedan en su propiedad:**
${activos_digitales_lista}

> **ROI SaaS (servicio): ${roi_saas}** — calculado solo sobre OPEX (fee de servicio), sin mezclar el activo digital que es suyo.

---

## 🗓️ Plan de Trabajo: 7/30/60/90 Días

### Primeros 7 Días (Activación)
${plan_7_days}

### Primeros 30 Días (Quick Wins)
${plan_30_days}

### Días 31-60 (Consolidación)
${plan_60_days}

### Días 61-90 (Optimización)
${plan_90_days}

---

## 📊 METRICAS DE VISIBILIDAD

${analytics_section}

## 🌐 Transparencia de IAO (Inteligencia Artificial Outside)

El análisis de IAO utiliza APIs de terceros (OpenRouter, Google AI, Perplexity) para evaluar si tu hotel aparece en recomendaciones de ChatGPT, Google AI Overviews y otros sistemas de IA.

*Ver Anexo Técnico: Infraestructura IAO al final del documento.*

## 🛡️ GARANTÍAS: Protección para usted

### 1. Value-Capture Cap: Solo cobramos si usted gana

**Nuestro modelo nos prohíbe cobrarle más del 50% de lo que recuperamos.** Si su recuperación proyectada es de $X, nuestro fee mensual NUNCA excederá el 50% de X. Esto significa que usted siempre se queda con al menos la mitad de cada peso que recupera.

### 2. Resultados garantizados
Si en ${guarantee_satisfaction_days} días no ve un aumento del ${guarantee_improvement_percent}% en consultas directas, **le extendemos el servicio 1 mes gratis**. Sin excusas.
Instalamos tracking propio en el Día 7 — sin necesidad de que tengas GA4.

### 3. Garantía Día 55: Auditoría automática con KPI verificable

El **Día 55** de nuestro servicio, nuestra IA ejecuta una auditoría completa de todos los entregables.
**Métrica auditada:** ${garantia_metrica}
**Umbral mínimo:** ${garantia_umbral}
**Si no se cumple:** ${garantia_consecuencia}
Sin reclamos, sin papeleo, sin llamadas.

### 4. Sin compromiso
Contrato mes a mes. Si en cualquier momento no quiere continuar, nos avisa con ${guarantee_delivery_days} días. Sin penalizaciones.

### 5. Transparencia en cada cifra
Reporte mensual con métricas reales. Usted ve exactamente qué está pasando.



---

${pilot_section}
---

${closing_pitch}
---

## 💳 Formas de Pago

- Transferencia / PSE
- Tarjeta crédito (${installment_label})

**Descuentos por pago anticipado:**
- Trimestral: ${quarterly_discount}%
- Semestral: ${semiannual_discount}%

---

## ✍️ ACEPTACIÓN

**Nombre**: ___________________________  
**Cargo**: ___________________________  
**Fecha**: ___________________________

---

## 📞 CONTACTO

**IA Hoteles Agent**  
*Especialistas en visibilidad digital para hoteles boutique y negocios locales*

Email: contacto@iahoteles.co

---

*Propuesta válida por 15 días. Cupo limitado para nuevos clientes por mes.*

---

## 📋 Transparencia tecnológica

Nuestro análisis utiliza múltiples modelos de inteligencia artificial
(ChatGPT, Gemini, Perplexity) para evaluar cómo los motores de búsqueda
y asistentes de IA ven su hotel en internet. El costo de estas consultas
lo absorbemos nosotros como parte del servicio — usted no paga nada adicional.
