# Guia de Resolucion: Conflicto de WhatsApp
## Zione

**Fecha**: 2026-07-30

### Numeros Detectados

| Fuente | Numero | Referencia |
|--------|--------|------------|
| Sitio web (schema) | +573103724544 | Extraido del markup Schema.org del sitio web |
| Google Business Profile | 311 6079036 | Perfil verificado con 965 reseñas |
| Boton WhatsApp (wa.me) | +573116079036 | Numero extraido del enlace wa.me en el HTML del sitio |

### Conflicto: Boton WhatsApp apunta a numero diferente

El boton de WhatsApp en su sitio web contiene el enlace `wa.me/573116079036`,
pero el numero registrado en Google Business Profile es `311 6079036`.

Esto significa que cuando un visitante hace clic en el boton de WhatsApp,
se comunicara con un numero **diferente** al que aparece en Google.
Esto genera confusion y puede resultar en mensajes perdidos.

### El Problema

Cuando un visitante busca su hotel y encuentra numeros diferentes en su
web vs Google, se genera confusion. Esto resulta en:
- Pérdida de confianza del potencial huésped
- Reservas perdidas por frustracion
- Mensajes a numeros incorrectos o inactivos

### Numero Recomendado

**Recomendamos usar el numero de Google Business Profile:** `311 6079036`

Razon: Su perfil de Google tiene 965 reseñas y calificacion de 4.4/5. Este es el numero que los viajeros confian al buscar su hotel. Unificarlo en su web eliminara la confusion.

### Checklist de Resolucion

- [ ] Decida cual es el numero de WhatsApp correcto (el que vigila activamente)
- [ ] Actualice su perfil de Google Business Profile con el numero correcto
- [ ] Actualice el numero en el schema de su sitio web
- [ ] Si usa WhatsApp Business, verifique que el perfil este completo
- [ ] Verifique que el mensaje de bienvenida en WhatsApp este configurado
- [ ] Haga una prueba: llame/envie mensaje al numero desde otro telefono

### Como Actualizar el Numero en Google Business Profile

1. Ingrese a [Google Business Profile](https://business.google.com/)
2. Seleccione su hotel
3. Vaya a "Informacion"
4. Edite el campo "Telefono"
5. Ingrese el numero correcto con indicativo de pais (+57)
6. Guarde los cambios

### Como Actualizar el Numero en su Sitio Web

1. Ingrese al administrador de su sitio (WordPress, etc.)
2. Busque el numero actual de contacto/WhatsApp
3. Reemplazelo con el numero correcto
4. Si tiene Schema.org markup, actualice el campo `telephone`
5. Guarde y verifique que el boton de WhatsApp apunte al numero correcto

---

*Guia generada automaticamente por IA Hoteles v4.0*