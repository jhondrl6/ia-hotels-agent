# Sync Contract Report

## Diagnóstico Comercial vs GEO

**Hotel:** Zi One Luxury Pereira
**URL:** https://zione.co/

---

### Diagnóstico Comercial

- **Pérdida mensual:** No especificada
- **Paquete recomendado:** N/A

### Diagnóstico GEO

- **Score GEO:** 23/100
- **Banda:** CRITICAL
- **Gaps bloqueantes:**
  - S1: No Hotel schema detected
  - M2: Meta description missing or too short
  - C2: No statistics (rating/reviews) available

---

## Análisis de Consistencia

**Consistente:** ✅ Sí
**Combinación:** Crisis técnica confirma pérdida
**Sync Score:** 0.75

### Recomendación

CRISIS TÉCNICA: El sitio tiene score GEO crítico que contribuye directamente a la pérdida comercial. La propuesta debe ser urgente, con enfoque técnico prioritario. Resolver gaps críticos (llms.txt, robots.txt, schema.org) es condición necesaria para reducir pérdidas.

---
*Generado: 2026-08-24 16:35 UTC*